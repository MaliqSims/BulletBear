gdjs.ShowroomCode = {};
gdjs.ShowroomCode.forEachCount0_3 = 0;

gdjs.ShowroomCode.forEachCount1_3 = 0;

gdjs.ShowroomCode.forEachCount2_3 = 0;

gdjs.ShowroomCode.forEachIndex3 = 0;

gdjs.ShowroomCode.forEachObjects3 = [];

gdjs.ShowroomCode.forEachTotalCount3 = 0;

gdjs.ShowroomCode.GDFloorObjects1= [];
gdjs.ShowroomCode.GDFloorObjects2= [];
gdjs.ShowroomCode.GDFloorObjects3= [];
gdjs.ShowroomCode.GDFloorObjects4= [];
gdjs.ShowroomCode.GDFloorObjects5= [];
gdjs.ShowroomCode.GDPlayerObjects1= [];
gdjs.ShowroomCode.GDPlayerObjects2= [];
gdjs.ShowroomCode.GDPlayerObjects3= [];
gdjs.ShowroomCode.GDPlayerObjects4= [];
gdjs.ShowroomCode.GDPlayerObjects5= [];
gdjs.ShowroomCode.GDGunObjects1= [];
gdjs.ShowroomCode.GDGunObjects2= [];
gdjs.ShowroomCode.GDGunObjects3= [];
gdjs.ShowroomCode.GDGunObjects4= [];
gdjs.ShowroomCode.GDGunObjects5= [];
gdjs.ShowroomCode.GDBulletObjects1= [];
gdjs.ShowroomCode.GDBulletObjects2= [];
gdjs.ShowroomCode.GDBulletObjects3= [];
gdjs.ShowroomCode.GDBulletObjects4= [];
gdjs.ShowroomCode.GDBulletObjects5= [];
gdjs.ShowroomCode.GDGhostEnemyObjects1= [];
gdjs.ShowroomCode.GDGhostEnemyObjects2= [];
gdjs.ShowroomCode.GDGhostEnemyObjects3= [];
gdjs.ShowroomCode.GDGhostEnemyObjects4= [];
gdjs.ShowroomCode.GDGhostEnemyObjects5= [];
gdjs.ShowroomCode.GDSpiderEnemyObjects1= [];
gdjs.ShowroomCode.GDSpiderEnemyObjects2= [];
gdjs.ShowroomCode.GDSpiderEnemyObjects3= [];
gdjs.ShowroomCode.GDSpiderEnemyObjects4= [];
gdjs.ShowroomCode.GDSpiderEnemyObjects5= [];
gdjs.ShowroomCode.GDImpEnemyObjects1= [];
gdjs.ShowroomCode.GDImpEnemyObjects2= [];
gdjs.ShowroomCode.GDImpEnemyObjects3= [];
gdjs.ShowroomCode.GDImpEnemyObjects4= [];
gdjs.ShowroomCode.GDImpEnemyObjects5= [];
gdjs.ShowroomCode.GDCenterObjects1= [];
gdjs.ShowroomCode.GDCenterObjects2= [];
gdjs.ShowroomCode.GDCenterObjects3= [];
gdjs.ShowroomCode.GDCenterObjects4= [];
gdjs.ShowroomCode.GDCenterObjects5= [];
gdjs.ShowroomCode.GDSpawnPointsObjects1= [];
gdjs.ShowroomCode.GDSpawnPointsObjects2= [];
gdjs.ShowroomCode.GDSpawnPointsObjects3= [];
gdjs.ShowroomCode.GDSpawnPointsObjects4= [];
gdjs.ShowroomCode.GDSpawnPointsObjects5= [];
gdjs.ShowroomCode.GDSpiderSpawnPointsObjects1= [];
gdjs.ShowroomCode.GDSpiderSpawnPointsObjects2= [];
gdjs.ShowroomCode.GDSpiderSpawnPointsObjects3= [];
gdjs.ShowroomCode.GDSpiderSpawnPointsObjects4= [];
gdjs.ShowroomCode.GDSpiderSpawnPointsObjects5= [];
gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects1= [];
gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects2= [];
gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects3= [];
gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects4= [];
gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects5= [];
gdjs.ShowroomCode.GDWallCollisionObjects1= [];
gdjs.ShowroomCode.GDWallCollisionObjects2= [];
gdjs.ShowroomCode.GDWallCollisionObjects3= [];
gdjs.ShowroomCode.GDWallCollisionObjects4= [];
gdjs.ShowroomCode.GDWallCollisionObjects5= [];
gdjs.ShowroomCode.GDvignetteObjects1= [];
gdjs.ShowroomCode.GDvignetteObjects2= [];
gdjs.ShowroomCode.GDvignetteObjects3= [];
gdjs.ShowroomCode.GDvignetteObjects4= [];
gdjs.ShowroomCode.GDvignetteObjects5= [];
gdjs.ShowroomCode.GDRedFlatBarObjects1= [];
gdjs.ShowroomCode.GDRedFlatBarObjects2= [];
gdjs.ShowroomCode.GDRedFlatBarObjects3= [];
gdjs.ShowroomCode.GDRedFlatBarObjects4= [];
gdjs.ShowroomCode.GDRedFlatBarObjects5= [];
gdjs.ShowroomCode.GDEXP_9595PointObjects1= [];
gdjs.ShowroomCode.GDEXP_9595PointObjects2= [];
gdjs.ShowroomCode.GDEXP_9595PointObjects3= [];
gdjs.ShowroomCode.GDEXP_9595PointObjects4= [];
gdjs.ShowroomCode.GDEXP_9595PointObjects5= [];
gdjs.ShowroomCode.GDStatsObjects1= [];
gdjs.ShowroomCode.GDStatsObjects2= [];
gdjs.ShowroomCode.GDStatsObjects3= [];
gdjs.ShowroomCode.GDStatsObjects4= [];
gdjs.ShowroomCode.GDStatsObjects5= [];
gdjs.ShowroomCode.GDPowerButtonObjects1= [];
gdjs.ShowroomCode.GDPowerButtonObjects2= [];
gdjs.ShowroomCode.GDPowerButtonObjects3= [];
gdjs.ShowroomCode.GDPowerButtonObjects4= [];
gdjs.ShowroomCode.GDPowerButtonObjects5= [];
gdjs.ShowroomCode.GDFireRateButtonObjects1= [];
gdjs.ShowroomCode.GDFireRateButtonObjects2= [];
gdjs.ShowroomCode.GDFireRateButtonObjects3= [];
gdjs.ShowroomCode.GDFireRateButtonObjects4= [];
gdjs.ShowroomCode.GDFireRateButtonObjects5= [];
gdjs.ShowroomCode.GDAccuracyButtonObjects1= [];
gdjs.ShowroomCode.GDAccuracyButtonObjects2= [];
gdjs.ShowroomCode.GDAccuracyButtonObjects3= [];
gdjs.ShowroomCode.GDAccuracyButtonObjects4= [];
gdjs.ShowroomCode.GDAccuracyButtonObjects5= [];
gdjs.ShowroomCode.GDWaveNumberObjects1= [];
gdjs.ShowroomCode.GDWaveNumberObjects2= [];
gdjs.ShowroomCode.GDWaveNumberObjects3= [];
gdjs.ShowroomCode.GDWaveNumberObjects4= [];
gdjs.ShowroomCode.GDWaveNumberObjects5= [];
gdjs.ShowroomCode.GDEnemyBulletObjects1= [];
gdjs.ShowroomCode.GDEnemyBulletObjects2= [];
gdjs.ShowroomCode.GDEnemyBulletObjects3= [];
gdjs.ShowroomCode.GDEnemyBulletObjects4= [];
gdjs.ShowroomCode.GDEnemyBulletObjects5= [];
gdjs.ShowroomCode.GDShadowObjects1= [];
gdjs.ShowroomCode.GDShadowObjects2= [];
gdjs.ShowroomCode.GDShadowObjects3= [];
gdjs.ShowroomCode.GDShadowObjects4= [];
gdjs.ShowroomCode.GDShadowObjects5= [];
gdjs.ShowroomCode.GDDropObjects1= [];
gdjs.ShowroomCode.GDDropObjects2= [];
gdjs.ShowroomCode.GDDropObjects3= [];
gdjs.ShowroomCode.GDDropObjects4= [];
gdjs.ShowroomCode.GDDropObjects5= [];
gdjs.ShowroomCode.GDMovementObjects1= [];
gdjs.ShowroomCode.GDMovementObjects2= [];
gdjs.ShowroomCode.GDMovementObjects3= [];
gdjs.ShowroomCode.GDMovementObjects4= [];
gdjs.ShowroomCode.GDMovementObjects5= [];
gdjs.ShowroomCode.GDAimingObjects1= [];
gdjs.ShowroomCode.GDAimingObjects2= [];
gdjs.ShowroomCode.GDAimingObjects3= [];
gdjs.ShowroomCode.GDAimingObjects4= [];
gdjs.ShowroomCode.GDAimingObjects5= [];
gdjs.ShowroomCode.GDPlayerHealthBarObjects1= [];
gdjs.ShowroomCode.GDPlayerHealthBarObjects2= [];
gdjs.ShowroomCode.GDPlayerHealthBarObjects3= [];
gdjs.ShowroomCode.GDPlayerHealthBarObjects4= [];
gdjs.ShowroomCode.GDPlayerHealthBarObjects5= [];
gdjs.ShowroomCode.GDHeartObjects1= [];
gdjs.ShowroomCode.GDHeartObjects2= [];
gdjs.ShowroomCode.GDHeartObjects3= [];
gdjs.ShowroomCode.GDHeartObjects4= [];
gdjs.ShowroomCode.GDHeartObjects5= [];
gdjs.ShowroomCode.GDHeart2Objects1= [];
gdjs.ShowroomCode.GDHeart2Objects2= [];
gdjs.ShowroomCode.GDHeart2Objects3= [];
gdjs.ShowroomCode.GDHeart2Objects4= [];
gdjs.ShowroomCode.GDHeart2Objects5= [];
gdjs.ShowroomCode.GDTransitionObjects1= [];
gdjs.ShowroomCode.GDTransitionObjects2= [];
gdjs.ShowroomCode.GDTransitionObjects3= [];
gdjs.ShowroomCode.GDTransitionObjects4= [];
gdjs.ShowroomCode.GDTransitionObjects5= [];
gdjs.ShowroomCode.GDDarkenObjects1= [];
gdjs.ShowroomCode.GDDarkenObjects2= [];
gdjs.ShowroomCode.GDDarkenObjects3= [];
gdjs.ShowroomCode.GDDarkenObjects4= [];
gdjs.ShowroomCode.GDDarkenObjects5= [];


gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDPlayerHealthBarObjects1Objects = Hashtable.newFrom({"PlayerHealthBar": gdjs.ShowroomCode.GDPlayerHealthBarObjects1});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDGunObjects2Objects = Hashtable.newFrom({"Gun": gdjs.ShowroomCode.GDGunObjects2});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDGunObjects2Objects = Hashtable.newFrom({"Gun": gdjs.ShowroomCode.GDGunObjects2});
gdjs.ShowroomCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ShowroomCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.ShowroomCode.GDGunObjects2);
{for(var i = 0, len = gdjs.ShowroomCode.GDGunObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGunObjects2[i].setAnimationName("laser");
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDBulletObjects2[i].setAnimationName("lasergun");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 2;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ShowroomCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.ShowroomCode.GDGunObjects2);
{for(var i = 0, len = gdjs.ShowroomCode.GDGunObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGunObjects2[i].setAnimationName("mingun");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDGunObjects2Objects, 5, 5, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDGunObjects2Objects, 5, 5, "");
}{for(var i = 0, len = gdjs.ShowroomCode.GDGunObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGunObjects2[i].getBehavior("Resizable").setSize(50, 20);
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDBulletObjects2[i].setAnimationName("minigun");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isMobile());
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Aiming"), gdjs.ShowroomCode.GDAimingObjects1);
gdjs.copyArray(runtimeScene.getObjects("Movement"), gdjs.ShowroomCode.GDMovementObjects1);
{for(var i = 0, len = gdjs.ShowroomCode.GDMovementObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDMovementObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDAimingObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDAimingObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.ShowroomCode.eventsList1 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.ShowroomCode.GDFloorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Heart2"), gdjs.ShowroomCode.GDHeart2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("SpawnPoints"), gdjs.ShowroomCode.GDSpawnPointsObjects1);
gdjs.copyArray(runtimeScene.getObjects("SpiderSpawnPoints"), gdjs.ShowroomCode.GDSpiderSpawnPointsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.ShowroomCode.GDTransitionObjects1);
gdjs.copyArray(runtimeScene.getObjects("WallCollision"), gdjs.ShowroomCode.GDWallCollisionObjects1);
gdjs.copyArray(runtimeScene.getObjects("vignette"), gdjs.ShowroomCode.GDvignetteObjects1);
gdjs.ShowroomCode.GDPlayerHealthBarObjects1.length = 0;

{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "Vignette", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "Vignette", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.ShowroomCode.GDFloorObjects1.length !== 0 ? gdjs.ShowroomCode.GDFloorObjects1[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs.ShowroomCode.GDWallCollisionObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDWallCollisionObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDSpiderSpawnPointsObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDSpiderSpawnPointsObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDSpawnPointsObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDSpawnPointsObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDHeart2Objects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDHeart2Objects1[i].hide();
}
}{gdjs.evtsExt__CameraShake__SetLayerRotationAmplitude.func(runtimeScene, 1, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetDefaultZoomAmplitude.func(runtimeScene, 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetLayerTranslationAmplitude.func(runtimeScene, 1, 1, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__CameraShake__SetLayerShakingFrequency.func(runtimeScene, 5, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.5, "transition", 0);
}{for(var i = 0, len = gdjs.ShowroomCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDTransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 1, "Circular", "Backward", 0, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDPlayerHealthBarObjects1Objects, 30, 30, "UI");
}{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects1[i].getBehavior("Effect").enableEffect("Damaged", false);
}
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.ShowroomCode.GDvignetteObjects1.length !== 0 ? gdjs.ShowroomCode.GDvignetteObjects1[0] : null), true, "Vignette", 0);
}
{ //Subevents
gdjs.ShowroomCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDGhostEnemyObjects1Objects = Hashtable.newFrom({"GhostEnemy": gdjs.ShowroomCode.GDGhostEnemyObjects1});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDSpiderEnemyObjects1Objects = Hashtable.newFrom({"SpiderEnemy": gdjs.ShowroomCode.GDSpiderEnemyObjects1});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDImpEnemyObjects1Objects = Hashtable.newFrom({"ImpEnemy": gdjs.ShowroomCode.GDImpEnemyObjects1});
gdjs.ShowroomCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ShowroomCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.ShowroomCode.GDCenterObjects1);
gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.ShowroomCode.GDGhostEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.ShowroomCode.GDGunObjects1);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.ShowroomCode.GDImpEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.ShowroomCode.GDSpiderEnemyObjects1);
{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects1[i].setZOrder((gdjs.ShowroomCode.GDPlayerObjects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.ShowroomCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDBulletObjects1[i].setZOrder((gdjs.ShowroomCode.GDBulletObjects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.ShowroomCode.GDGhostEnemyObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGhostEnemyObjects1[i].setZOrder((gdjs.ShowroomCode.GDGhostEnemyObjects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.ShowroomCode.GDSpiderEnemyObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDSpiderEnemyObjects1[i].setZOrder((gdjs.ShowroomCode.GDSpiderEnemyObjects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.ShowroomCode.GDImpEnemyObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDImpEnemyObjects1[i].setZOrder((gdjs.ShowroomCode.GDImpEnemyObjects1[i].getPointY("")));
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDGunObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGunObjects1[i].setZOrder((( gdjs.ShowroomCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.ShowroomCode.GDPlayerObjects1[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDGhostEnemyObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGhostEnemyObjects1[i].separateFromObjectsList(gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDGhostEnemyObjects1Objects, false);
}
for(var i = 0, len = gdjs.ShowroomCode.GDSpiderEnemyObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDSpiderEnemyObjects1[i].separateFromObjectsList(gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDSpiderEnemyObjects1Objects, false);
}
for(var i = 0, len = gdjs.ShowroomCode.GDImpEnemyObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDImpEnemyObjects1[i].separateFromObjectsList(gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDImpEnemyObjects1Objects, false);
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDCenterObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDCenterObjects1[i].setZOrder(0);
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDCenterObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDCenterObjects1[i].putAroundObject((gdjs.ShowroomCode.GDPlayerObjects1.length !== 0 ? gdjs.ShowroomCode.GDPlayerObjects1[0] : null), 0, 0);
}
}}

}


};gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDCenterObjects2Objects = Hashtable.newFrom({"Center": gdjs.ShowroomCode.GDCenterObjects2});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.ShowroomCode.GDEnemyBulletObjects2});
gdjs.ShowroomCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.ShowroomCode.GDCenterObjects2 */
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.ShowroomCode.GDEnemyBulletObjects2);
/* Reuse gdjs.ShowroomCode.GDImpEnemyObjects2 */
{for(var i = 0, len = gdjs.ShowroomCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDImpEnemyObjects2[i].getBehavior("FireBullet").FireTowardPosition((gdjs.ShowroomCode.GDImpEnemyObjects2[i].getCenterXInScene()), (gdjs.ShowroomCode.GDImpEnemyObjects2[i].getCenterYInScene()), gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDEnemyBulletObjects2Objects, (( gdjs.ShowroomCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.ShowroomCode.GDCenterObjects2[0].getCenterXInScene()), (( gdjs.ShowroomCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.ShowroomCode.GDCenterObjects2[0].getCenterYInScene()), 35, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDCenterObjects2Objects = Hashtable.newFrom({"Center": gdjs.ShowroomCode.GDCenterObjects2});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ShowroomCode.GDPlayerObjects2});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDHeart2Objects2Objects = Hashtable.newFrom({"Heart2": gdjs.ShowroomCode.GDHeart2Objects2});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDHeartObjects2Objects = Hashtable.newFrom({"Heart": gdjs.ShowroomCode.GDHeartObjects2});
gdjs.ShowroomCode.asyncCallback16099396 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getGame().getVariables().getFromIndex(2).add(1);
}}
gdjs.ShowroomCode.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(25), (runtimeScene) => (gdjs.ShowroomCode.asyncCallback16099396(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDSpawnPointsObjects2Objects = Hashtable.newFrom({"SpawnPoints": gdjs.ShowroomCode.GDSpawnPointsObjects2});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDSpiderSpawnPointsObjects3Objects = Hashtable.newFrom({"SpiderSpawnPoints": gdjs.ShowroomCode.GDSpiderSpawnPointsObjects3});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDShadowObjects3Objects = Hashtable.newFrom({"Shadow": gdjs.ShowroomCode.GDShadowObjects3});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDDropObjects3Objects = Hashtable.newFrom({"Drop": gdjs.ShowroomCode.GDDropObjects3});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDSpiderEnemyObjects4Objects = Hashtable.newFrom({"SpiderEnemy": gdjs.ShowroomCode.GDSpiderEnemyObjects4});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDHealthBar_95959595EnemyObjects4Objects = Hashtable.newFrom({"HealthBar_Enemy": gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects4});
gdjs.ShowroomCode.asyncCallback16103444 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("SpiderSpawnPoints"), gdjs.ShowroomCode.GDSpiderSpawnPointsObjects4);

gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects4.length = 0;

gdjs.ShowroomCode.GDSpiderEnemyObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDSpiderEnemyObjects4Objects, (( gdjs.ShowroomCode.GDSpiderSpawnPointsObjects4.length === 0 ) ? 0 :gdjs.ShowroomCode.GDSpiderSpawnPointsObjects4[0].getPointX("")), (( gdjs.ShowroomCode.GDSpiderSpawnPointsObjects4.length === 0 ) ? 0 :gdjs.ShowroomCode.GDSpiderSpawnPointsObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.ShowroomCode.GDSpiderEnemyObjects4.length ;i < len;++i) {
    gdjs.ShowroomCode.GDSpiderEnemyObjects4[i].getBehavior("Health").SetMaxHealthOp(2 + Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) / 3), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDSpiderEnemyObjects4.length ;i < len;++i) {
    gdjs.ShowroomCode.GDSpiderEnemyObjects4[i].getBehavior("Health").SetHealth((gdjs.ShowroomCode.GDSpiderEnemyObjects4[i].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDHealthBar_95959595EnemyObjects4Objects, (( gdjs.ShowroomCode.GDSpiderEnemyObjects4.length === 0 ) ? 0 :gdjs.ShowroomCode.GDSpiderEnemyObjects4[0].getPointX("")), (( gdjs.ShowroomCode.GDSpiderEnemyObjects4.length === 0 ) ? 0 :gdjs.ShowroomCode.GDSpiderEnemyObjects4[0].getPointY("")), "");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects4.length !== 0 ? gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects4[0] : null), (gdjs.ShowroomCode.GDSpiderEnemyObjects4.length !== 0 ? gdjs.ShowroomCode.GDSpiderEnemyObjects4[0] : null));
}}
gdjs.ShowroomCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.ShowroomCode.GDSpiderSpawnPointsObjects3) asyncObjectsList.addObject("SpiderSpawnPoints", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.ShowroomCode.asyncCallback16103444(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDGhostEnemyObjects3Objects = Hashtable.newFrom({"GhostEnemy": gdjs.ShowroomCode.GDGhostEnemyObjects3});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDHealthBar_95959595EnemyObjects3Objects = Hashtable.newFrom({"HealthBar_Enemy": gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects3});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDImpEnemyObjects3Objects = Hashtable.newFrom({"ImpEnemy": gdjs.ShowroomCode.GDImpEnemyObjects3});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDHealthBar_95959595EnemyObjects3Objects = Hashtable.newFrom({"HealthBar_Enemy": gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects3});
gdjs.ShowroomCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("SpiderSpawnPoints"), gdjs.ShowroomCode.GDSpiderSpawnPointsObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDSpiderSpawnPointsObjects3Objects);
}
if (isConditionTrue_0) {
/* Reuse gdjs.ShowroomCode.GDSpiderSpawnPointsObjects3 */
gdjs.ShowroomCode.GDDropObjects3.length = 0;

gdjs.copyArray(gdjs.ShowroomCode.GDShadowObjects2, gdjs.ShowroomCode.GDShadowObjects3);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDShadowObjects3Objects, (( gdjs.ShowroomCode.GDSpiderSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.ShowroomCode.GDSpiderSpawnPointsObjects3[0].getPointX("")), (( gdjs.ShowroomCode.GDSpiderSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.ShowroomCode.GDSpiderSpawnPointsObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.ShowroomCode.GDShadowObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDShadowObjects3[i].setScale(0);
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDShadowObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDShadowObjects3[i].getBehavior("Tween").addObjectScaleTween("Grow", 1, 1, "linear", 1000, true, false);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDDropObjects3Objects, (( gdjs.ShowroomCode.GDSpiderSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.ShowroomCode.GDSpiderSpawnPointsObjects3[0].getPointX("")), (( gdjs.ShowroomCode.GDSpiderSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.ShowroomCode.GDSpiderSpawnPointsObjects3[0].getPointY("")) - 100, "");
}{for(var i = 0, len = gdjs.ShowroomCode.GDDropObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDDropObjects3[i].getBehavior("Tween").addObjectPositionYTween("Drop", (gdjs.ShowroomCode.GDDropObjects3[i].getPointY("")) + 100, "linear", 1000, true);
}
}
{ //Subevents
gdjs.ShowroomCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.ShowroomCode.GDSpawnPointsObjects2, gdjs.ShowroomCode.GDSpawnPointsObjects3);

gdjs.ShowroomCode.GDGhostEnemyObjects3.length = 0;

gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDGhostEnemyObjects3Objects, (( gdjs.ShowroomCode.GDSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.ShowroomCode.GDSpawnPointsObjects3[0].getPointX("")), (( gdjs.ShowroomCode.GDSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.ShowroomCode.GDSpawnPointsObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.ShowroomCode.GDGhostEnemyObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGhostEnemyObjects3[i].getBehavior("Health").SetMaxHealthOp(3 + Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) / 3), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDGhostEnemyObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGhostEnemyObjects3[i].getBehavior("Health").SetHealth((gdjs.ShowroomCode.GDGhostEnemyObjects3[i].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDHealthBar_95959595EnemyObjects3Objects, (( gdjs.ShowroomCode.GDGhostEnemyObjects3.length === 0 ) ? 0 :gdjs.ShowroomCode.GDGhostEnemyObjects3[0].getPointX("")), (( gdjs.ShowroomCode.GDGhostEnemyObjects3.length === 0 ) ? 0 :gdjs.ShowroomCode.GDGhostEnemyObjects3[0].getPointY("")), "");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects3.length !== 0 ? gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects3[0] : null), (gdjs.ShowroomCode.GDGhostEnemyObjects3.length !== 0 ? gdjs.ShowroomCode.GDGhostEnemyObjects3[0] : null));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 2;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.ShowroomCode.GDSpawnPointsObjects2, gdjs.ShowroomCode.GDSpawnPointsObjects3);

gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects3.length = 0;

gdjs.ShowroomCode.GDImpEnemyObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDImpEnemyObjects3Objects, (( gdjs.ShowroomCode.GDSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.ShowroomCode.GDSpawnPointsObjects3[0].getPointX("")), (( gdjs.ShowroomCode.GDSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.ShowroomCode.GDSpawnPointsObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.ShowroomCode.GDImpEnemyObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDImpEnemyObjects3[i].getBehavior("Health").SetMaxHealthOp(4 + Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) / 3), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDImpEnemyObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDImpEnemyObjects3[i].getBehavior("Health").SetHealth((gdjs.ShowroomCode.GDImpEnemyObjects3[i].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDHealthBar_95959595EnemyObjects3Objects, (( gdjs.ShowroomCode.GDImpEnemyObjects3.length === 0 ) ? 0 :gdjs.ShowroomCode.GDImpEnemyObjects3[0].getPointX("")), (( gdjs.ShowroomCode.GDImpEnemyObjects3.length === 0 ) ? 0 :gdjs.ShowroomCode.GDImpEnemyObjects3[0].getPointY("")), "");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects3.length !== 0 ? gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects3[0] : null), (gdjs.ShowroomCode.GDImpEnemyObjects3.length !== 0 ? gdjs.ShowroomCode.GDImpEnemyObjects3[0] : null));
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Enemy Spawn");
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(gdjs.randomInRange(0, Math.min(Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) / 3), 2)));
}}

}


};gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDHealthBar_95959595EnemyObjects3Objects = Hashtable.newFrom({"HealthBar_Enemy": gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects3});
gdjs.ShowroomCode.eventsList7 = function(runtimeScene) {

};gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.ShowroomCode.GDBulletObjects2});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDGhostEnemyObjects2ObjectsGDgdjs_9546ShowroomCode_9546GDSpiderEnemyObjects2ObjectsGDgdjs_9546ShowroomCode_9546GDImpEnemyObjects2Objects = Hashtable.newFrom({"GhostEnemy": gdjs.ShowroomCode.GDGhostEnemyObjects2, "SpiderEnemy": gdjs.ShowroomCode.GDSpiderEnemyObjects2, "ImpEnemy": gdjs.ShowroomCode.GDImpEnemyObjects2});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDHealthBar_95959595EnemyObjects2Objects = Hashtable.newFrom({"HealthBar_Enemy": gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects2});
gdjs.ShowroomCode.eventsList8 = function(runtimeScene) {

{

/* Reuse gdjs.ShowroomCode.GDGhostEnemyObjects2 */
gdjs.copyArray(runtimeScene.getObjects("HealthBar_Enemy"), gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects2);
/* Reuse gdjs.ShowroomCode.GDImpEnemyObjects2 */
/* Reuse gdjs.ShowroomCode.GDSpiderEnemyObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDHealthBar_95959595EnemyObjects2Objects, (gdjs.ShowroomCode.GDGhostEnemyObjects2.length !== 0 ? gdjs.ShowroomCode.GDGhostEnemyObjects2[0] : (gdjs.ShowroomCode.GDSpiderEnemyObjects2.length !== 0 ? gdjs.ShowroomCode.GDSpiderEnemyObjects2[0] : (gdjs.ShowroomCode.GDImpEnemyObjects2.length !== 0 ? gdjs.ShowroomCode.GDImpEnemyObjects2[0] : null))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
/* Reuse gdjs.ShowroomCode.GDGhostEnemyObjects2 */
/* Reuse gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects2 */
/* Reuse gdjs.ShowroomCode.GDImpEnemyObjects2 */
/* Reuse gdjs.ShowroomCode.GDSpiderEnemyObjects2 */
{for(var i = 0, len = gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects2[i].setWidth(((( gdjs.ShowroomCode.GDImpEnemyObjects2.length === 0 ) ? (( gdjs.ShowroomCode.GDSpiderEnemyObjects2.length === 0 ) ? (( gdjs.ShowroomCode.GDGhostEnemyObjects2.length === 0 ) ? 0 :gdjs.ShowroomCode.GDGhostEnemyObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.ShowroomCode.GDSpiderEnemyObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.ShowroomCode.GDImpEnemyObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.ShowroomCode.GDImpEnemyObjects2.length === 0 ) ? (( gdjs.ShowroomCode.GDSpiderEnemyObjects2.length === 0 ) ? (( gdjs.ShowroomCode.GDGhostEnemyObjects2.length === 0 ) ? 0 :gdjs.ShowroomCode.GDGhostEnemyObjects2[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.ShowroomCode.GDSpiderEnemyObjects2[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.ShowroomCode.GDImpEnemyObjects2[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 12);
}
}}

}


};gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.ShowroomCode.GDBulletObjects2});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDGhostEnemyObjects2ObjectsGDgdjs_9546ShowroomCode_9546GDSpiderEnemyObjects2ObjectsGDgdjs_9546ShowroomCode_9546GDImpEnemyObjects2Objects = Hashtable.newFrom({"GhostEnemy": gdjs.ShowroomCode.GDGhostEnemyObjects2, "SpiderEnemy": gdjs.ShowroomCode.GDSpiderEnemyObjects2, "ImpEnemy": gdjs.ShowroomCode.GDImpEnemyObjects2});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDHealthBar_95959595EnemyObjects2Objects = Hashtable.newFrom({"HealthBar_Enemy": gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects2});
gdjs.ShowroomCode.eventsList9 = function(runtimeScene) {

{

/* Reuse gdjs.ShowroomCode.GDGhostEnemyObjects2 */
gdjs.copyArray(runtimeScene.getObjects("HealthBar_Enemy"), gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects2);
/* Reuse gdjs.ShowroomCode.GDImpEnemyObjects2 */
/* Reuse gdjs.ShowroomCode.GDSpiderEnemyObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDHealthBar_95959595EnemyObjects2Objects, (gdjs.ShowroomCode.GDGhostEnemyObjects2.length !== 0 ? gdjs.ShowroomCode.GDGhostEnemyObjects2[0] : (gdjs.ShowroomCode.GDSpiderEnemyObjects2.length !== 0 ? gdjs.ShowroomCode.GDSpiderEnemyObjects2[0] : (gdjs.ShowroomCode.GDImpEnemyObjects2.length !== 0 ? gdjs.ShowroomCode.GDImpEnemyObjects2[0] : null))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
/* Reuse gdjs.ShowroomCode.GDGhostEnemyObjects2 */
/* Reuse gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects2 */
/* Reuse gdjs.ShowroomCode.GDImpEnemyObjects2 */
/* Reuse gdjs.ShowroomCode.GDSpiderEnemyObjects2 */
{for(var i = 0, len = gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects2[i].setWidth(((( gdjs.ShowroomCode.GDImpEnemyObjects2.length === 0 ) ? (( gdjs.ShowroomCode.GDSpiderEnemyObjects2.length === 0 ) ? (( gdjs.ShowroomCode.GDGhostEnemyObjects2.length === 0 ) ? 0 :gdjs.ShowroomCode.GDGhostEnemyObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.ShowroomCode.GDSpiderEnemyObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.ShowroomCode.GDImpEnemyObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / (( gdjs.ShowroomCode.GDImpEnemyObjects2.length === 0 ) ? (( gdjs.ShowroomCode.GDSpiderEnemyObjects2.length === 0 ) ? (( gdjs.ShowroomCode.GDGhostEnemyObjects2.length === 0 ) ? 0 :gdjs.ShowroomCode.GDGhostEnemyObjects2[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.ShowroomCode.GDSpiderEnemyObjects2[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) :gdjs.ShowroomCode.GDImpEnemyObjects2[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)))) * 12);
}
}}

}


};gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDHealthBar_95959595EnemyObjects2Objects = Hashtable.newFrom({"HealthBar_Enemy": gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects2});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDEXP_95959595PointObjects1Objects = Hashtable.newFrom({"EXP_Point": gdjs.ShowroomCode.GDEXP_9595PointObjects1});
gdjs.ShowroomCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.ShowroomCode.GDGhostEnemyObjects1, gdjs.ShowroomCode.GDGhostEnemyObjects2);

gdjs.copyArray(runtimeScene.getObjects("HealthBar_Enemy"), gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects2);
gdjs.copyArray(gdjs.ShowroomCode.GDImpEnemyObjects1, gdjs.ShowroomCode.GDImpEnemyObjects2);

gdjs.copyArray(gdjs.ShowroomCode.GDSpiderEnemyObjects1, gdjs.ShowroomCode.GDSpiderEnemyObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDHealthBar_95959595EnemyObjects2Objects, (gdjs.ShowroomCode.GDGhostEnemyObjects2.length !== 0 ? gdjs.ShowroomCode.GDGhostEnemyObjects2[0] : (gdjs.ShowroomCode.GDSpiderEnemyObjects2.length !== 0 ? gdjs.ShowroomCode.GDSpiderEnemyObjects2[0] : (gdjs.ShowroomCode.GDImpEnemyObjects2.length !== 0 ? gdjs.ShowroomCode.GDImpEnemyObjects2[0] : null))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
/* Reuse gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects2 */
{for(var i = 0, len = gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.ShowroomCode.GDGhostEnemyObjects1 */
/* Reuse gdjs.ShowroomCode.GDImpEnemyObjects1 */
/* Reuse gdjs.ShowroomCode.GDSpiderEnemyObjects1 */
gdjs.ShowroomCode.GDEXP_9595PointObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDEXP_95959595PointObjects1Objects, (( gdjs.ShowroomCode.GDImpEnemyObjects1.length === 0 ) ? (( gdjs.ShowroomCode.GDSpiderEnemyObjects1.length === 0 ) ? (( gdjs.ShowroomCode.GDGhostEnemyObjects1.length === 0 ) ? 0 :gdjs.ShowroomCode.GDGhostEnemyObjects1[0].getPointX("")) :gdjs.ShowroomCode.GDSpiderEnemyObjects1[0].getPointX("")) :gdjs.ShowroomCode.GDImpEnemyObjects1[0].getPointX("")), (( gdjs.ShowroomCode.GDImpEnemyObjects1.length === 0 ) ? (( gdjs.ShowroomCode.GDSpiderEnemyObjects1.length === 0 ) ? (( gdjs.ShowroomCode.GDGhostEnemyObjects1.length === 0 ) ? 0 :gdjs.ShowroomCode.GDGhostEnemyObjects1[0].getPointY("")) :gdjs.ShowroomCode.GDSpiderEnemyObjects1[0].getPointY("")) :gdjs.ShowroomCode.GDImpEnemyObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.ShowroomCode.GDGhostEnemyObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGhostEnemyObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ShowroomCode.GDSpiderEnemyObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDSpiderEnemyObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.ShowroomCode.GDImpEnemyObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDImpEnemyObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.ShowroomCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Enemy Spawn");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Wave");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Wave") > 30;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("WaveNumber"), gdjs.ShowroomCode.GDWaveNumberObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(1).add(1);
}{for(var i = 0, len = gdjs.ShowroomCode.GDWaveNumberObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDWaveNumberObjects2[i].setString("Wave: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1))));
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Wave");
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.ShowroomCode.GDImpEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDImpEnemyObjects2.length;i<l;++i) {
    if ( !(gdjs.ShowroomCode.GDImpEnemyObjects2[i].isCurrentAnimationName("Hurt")) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDImpEnemyObjects2[k] = gdjs.ShowroomCode.GDImpEnemyObjects2[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDImpEnemyObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.ShowroomCode.GDCenterObjects2);
/* Reuse gdjs.ShowroomCode.GDImpEnemyObjects2 */
{for(var i = 0, len = gdjs.ShowroomCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDImpEnemyObjects2[i].getBehavior("BoidsMovement").MoveToObject(gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDCenterObjects2Objects, 0.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.ShowroomCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.ShowroomCode.GDSpiderEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDSpiderEnemyObjects2.length;i<l;++i) {
    if ( !(gdjs.ShowroomCode.GDSpiderEnemyObjects2[i].isCurrentAnimationName("Hurt")) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDSpiderEnemyObjects2[k] = gdjs.ShowroomCode.GDSpiderEnemyObjects2[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDSpiderEnemyObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.ShowroomCode.GDCenterObjects2);
/* Reuse gdjs.ShowroomCode.GDSpiderEnemyObjects2 */
{for(var i = 0, len = gdjs.ShowroomCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDSpiderEnemyObjects2[i].addForceTowardObject((gdjs.ShowroomCode.GDCenterObjects2.length !== 0 ? gdjs.ShowroomCode.GDCenterObjects2[0] : null), 15, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.ShowroomCode.GDGhostEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDGhostEnemyObjects2.length;i<l;++i) {
    if ( !(gdjs.ShowroomCode.GDGhostEnemyObjects2[i].isCurrentAnimationName("Hurt")) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDGhostEnemyObjects2[k] = gdjs.ShowroomCode.GDGhostEnemyObjects2[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDGhostEnemyObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.ShowroomCode.GDCenterObjects2);
/* Reuse gdjs.ShowroomCode.GDGhostEnemyObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.ShowroomCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGhostEnemyObjects2[i].getBehavior("BoidsMovement").MoveToObject(gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDCenterObjects2Objects, 0.5, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGhostEnemyObjects2[i].getBehavior("BoidsMovement").AvoidObject(gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDPlayerObjects2Objects, 50, 30, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.ShowroomCode.GDCenterObjects2);
gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.ShowroomCode.GDGhostEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.ShowroomCode.GDImpEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.ShowroomCode.GDSpiderEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDGhostEnemyObjects2.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDGhostEnemyObjects2[i].getX() < (( gdjs.ShowroomCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.ShowroomCode.GDCenterObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDGhostEnemyObjects2[k] = gdjs.ShowroomCode.GDGhostEnemyObjects2[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDGhostEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDSpiderEnemyObjects2.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDSpiderEnemyObjects2[i].getX() < (( gdjs.ShowroomCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.ShowroomCode.GDCenterObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDSpiderEnemyObjects2[k] = gdjs.ShowroomCode.GDSpiderEnemyObjects2[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDSpiderEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDImpEnemyObjects2.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDImpEnemyObjects2[i].getX() < (( gdjs.ShowroomCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.ShowroomCode.GDCenterObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDImpEnemyObjects2[k] = gdjs.ShowroomCode.GDImpEnemyObjects2[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDImpEnemyObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.ShowroomCode.GDGhostEnemyObjects2 */
/* Reuse gdjs.ShowroomCode.GDImpEnemyObjects2 */
/* Reuse gdjs.ShowroomCode.GDSpiderEnemyObjects2 */
{for(var i = 0, len = gdjs.ShowroomCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGhostEnemyObjects2[i].flipX(false);
}
for(var i = 0, len = gdjs.ShowroomCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDSpiderEnemyObjects2[i].flipX(false);
}
for(var i = 0, len = gdjs.ShowroomCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDImpEnemyObjects2[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.ShowroomCode.GDCenterObjects2);
gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.ShowroomCode.GDGhostEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.ShowroomCode.GDImpEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.ShowroomCode.GDSpiderEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDGhostEnemyObjects2.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDGhostEnemyObjects2[i].getX() >= (( gdjs.ShowroomCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.ShowroomCode.GDCenterObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDGhostEnemyObjects2[k] = gdjs.ShowroomCode.GDGhostEnemyObjects2[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDGhostEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDSpiderEnemyObjects2.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDSpiderEnemyObjects2[i].getX() >= (( gdjs.ShowroomCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.ShowroomCode.GDCenterObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDSpiderEnemyObjects2[k] = gdjs.ShowroomCode.GDSpiderEnemyObjects2[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDSpiderEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDImpEnemyObjects2.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDImpEnemyObjects2[i].getX() >= (( gdjs.ShowroomCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.ShowroomCode.GDCenterObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDImpEnemyObjects2[k] = gdjs.ShowroomCode.GDImpEnemyObjects2[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDImpEnemyObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.ShowroomCode.GDGhostEnemyObjects2 */
/* Reuse gdjs.ShowroomCode.GDImpEnemyObjects2 */
/* Reuse gdjs.ShowroomCode.GDSpiderEnemyObjects2 */
{for(var i = 0, len = gdjs.ShowroomCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGhostEnemyObjects2[i].flipX(true);
}
for(var i = 0, len = gdjs.ShowroomCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDSpiderEnemyObjects2[i].flipX(true);
}
for(var i = 0, len = gdjs.ShowroomCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDImpEnemyObjects2[i].flipX(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Heart2"), gdjs.ShowroomCode.GDHeart2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.pickRandomObject((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDHeart2Objects2Objects);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(2)) == 0;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDPlayerObjects2[i].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) < 6 ) {
        isConditionTrue_1 = true;
        gdjs.ShowroomCode.GDPlayerObjects2[k] = gdjs.ShowroomCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDPlayerObjects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.ShowroomCode.GDHeart2Objects2 */
gdjs.ShowroomCode.GDHeartObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDHeartObjects2Objects, (( gdjs.ShowroomCode.GDHeart2Objects2.length === 0 ) ? 0 :gdjs.ShowroomCode.GDHeart2Objects2[0].getPointX("")), (( gdjs.ShowroomCode.GDHeart2Objects2.length === 0 ) ? 0 :gdjs.ShowroomCode.GDHeart2Objects2[0].getPointY("")), "");
}
{ //Subevents
gdjs.ShowroomCode.eventsList4(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("SpawnPoints"), gdjs.ShowroomCode.GDSpawnPointsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Enemy Spawn") > 3 / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDSpawnPointsObjects2Objects);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Shadow"), gdjs.ShowroomCode.GDShadowObjects2);
{for(var i = 0, len = gdjs.ShowroomCode.GDShadowObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDShadowObjects2[i].setScale(0);
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDShadowObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDShadowObjects2[i].getBehavior("Tween").addObjectScaleTween("Grow", 1, 1, "linear", 1000, true, false);
}
}
{ //Subevents
gdjs.ShowroomCode.eventsList6(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.ShowroomCode.GDGhostEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.ShowroomCode.GDImpEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.ShowroomCode.GDSpiderEnemyObjects2);

gdjs.ShowroomCode.forEachTotalCount3 = 0;
gdjs.ShowroomCode.forEachObjects3.length = 0;
gdjs.ShowroomCode.forEachCount0_3 = gdjs.ShowroomCode.GDGhostEnemyObjects2.length;
gdjs.ShowroomCode.forEachTotalCount3 += gdjs.ShowroomCode.forEachCount0_3;
gdjs.ShowroomCode.forEachObjects3.push.apply(gdjs.ShowroomCode.forEachObjects3,gdjs.ShowroomCode.GDGhostEnemyObjects2);
gdjs.ShowroomCode.forEachCount1_3 = gdjs.ShowroomCode.GDSpiderEnemyObjects2.length;
gdjs.ShowroomCode.forEachTotalCount3 += gdjs.ShowroomCode.forEachCount1_3;
gdjs.ShowroomCode.forEachObjects3.push.apply(gdjs.ShowroomCode.forEachObjects3,gdjs.ShowroomCode.GDSpiderEnemyObjects2);
gdjs.ShowroomCode.forEachCount2_3 = gdjs.ShowroomCode.GDImpEnemyObjects2.length;
gdjs.ShowroomCode.forEachTotalCount3 += gdjs.ShowroomCode.forEachCount2_3;
gdjs.ShowroomCode.forEachObjects3.push.apply(gdjs.ShowroomCode.forEachObjects3,gdjs.ShowroomCode.GDImpEnemyObjects2);
for (gdjs.ShowroomCode.forEachIndex3 = 0;gdjs.ShowroomCode.forEachIndex3 < gdjs.ShowroomCode.forEachTotalCount3;++gdjs.ShowroomCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar_Enemy"), gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects3);
gdjs.ShowroomCode.GDGhostEnemyObjects3.length = 0;

gdjs.ShowroomCode.GDImpEnemyObjects3.length = 0;

gdjs.ShowroomCode.GDSpiderEnemyObjects3.length = 0;


if (gdjs.ShowroomCode.forEachIndex3 < gdjs.ShowroomCode.forEachCount0_3) {
    gdjs.ShowroomCode.GDGhostEnemyObjects3.push(gdjs.ShowroomCode.forEachObjects3[gdjs.ShowroomCode.forEachIndex3]);
}
else if (gdjs.ShowroomCode.forEachIndex3 < gdjs.ShowroomCode.forEachCount0_3+gdjs.ShowroomCode.forEachCount1_3) {
    gdjs.ShowroomCode.GDSpiderEnemyObjects3.push(gdjs.ShowroomCode.forEachObjects3[gdjs.ShowroomCode.forEachIndex3]);
}
else if (gdjs.ShowroomCode.forEachIndex3 < gdjs.ShowroomCode.forEachCount0_3+gdjs.ShowroomCode.forEachCount1_3+gdjs.ShowroomCode.forEachCount2_3) {
    gdjs.ShowroomCode.GDImpEnemyObjects3.push(gdjs.ShowroomCode.forEachObjects3[gdjs.ShowroomCode.forEachIndex3]);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDHealthBar_95959595EnemyObjects3Objects, (gdjs.ShowroomCode.GDGhostEnemyObjects3.length !== 0 ? gdjs.ShowroomCode.GDGhostEnemyObjects3[0] : (gdjs.ShowroomCode.GDSpiderEnemyObjects3.length !== 0 ? gdjs.ShowroomCode.GDSpiderEnemyObjects3[0] : (gdjs.ShowroomCode.GDImpEnemyObjects3.length !== 0 ? gdjs.ShowroomCode.GDImpEnemyObjects3[0] : null))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects3[i].setPosition((( gdjs.ShowroomCode.GDImpEnemyObjects3.length === 0 ) ? (( gdjs.ShowroomCode.GDSpiderEnemyObjects3.length === 0 ) ? (( gdjs.ShowroomCode.GDGhostEnemyObjects3.length === 0 ) ? 0 :gdjs.ShowroomCode.GDGhostEnemyObjects3[0].getPointX("HealthBar")) :gdjs.ShowroomCode.GDSpiderEnemyObjects3[0].getPointX("HealthBar")) :gdjs.ShowroomCode.GDImpEnemyObjects3[0].getPointX("HealthBar")),(( gdjs.ShowroomCode.GDImpEnemyObjects3.length === 0 ) ? (( gdjs.ShowroomCode.GDSpiderEnemyObjects3.length === 0 ) ? (( gdjs.ShowroomCode.GDGhostEnemyObjects3.length === 0 ) ? 0 :gdjs.ShowroomCode.GDGhostEnemyObjects3[0].getPointY("HealthBar")) :gdjs.ShowroomCode.GDSpiderEnemyObjects3[0].getPointY("HealthBar")) :gdjs.ShowroomCode.GDImpEnemyObjects3[0].getPointY("HealthBar")));
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects3[i].setZOrder((( gdjs.ShowroomCode.GDImpEnemyObjects3.length === 0 ) ? (( gdjs.ShowroomCode.GDSpiderEnemyObjects3.length === 0 ) ? (( gdjs.ShowroomCode.GDGhostEnemyObjects3.length === 0 ) ? 0 :gdjs.ShowroomCode.GDGhostEnemyObjects3[0].getZOrder()) :gdjs.ShowroomCode.GDSpiderEnemyObjects3[0].getZOrder()) :gdjs.ShowroomCode.GDImpEnemyObjects3[0].getZOrder()) + 5);
}
}}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ShowroomCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.ShowroomCode.GDGhostEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.ShowroomCode.GDImpEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.ShowroomCode.GDSpiderEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDBulletObjects2Objects, gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDGhostEnemyObjects2ObjectsGDgdjs_9546ShowroomCode_9546GDSpiderEnemyObjects2ObjectsGDgdjs_9546ShowroomCode_9546GDImpEnemyObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.ShowroomCode.GDBulletObjects2 */
/* Reuse gdjs.ShowroomCode.GDGhostEnemyObjects2 */
/* Reuse gdjs.ShowroomCode.GDImpEnemyObjects2 */
/* Reuse gdjs.ShowroomCode.GDSpiderEnemyObjects2 */
{for(var i = 0, len = gdjs.ShowroomCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGhostEnemyObjects2[i].getBehavior("Health").Hit(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power")) * 2, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.ShowroomCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDSpiderEnemyObjects2[i].getBehavior("Health").Hit(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power")) * 2, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.ShowroomCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDImpEnemyObjects2[i].getBehavior("Health").Hit(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power")) * 2, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGhostEnemyObjects2[i].setAnimationName("Hurt");
}
for(var i = 0, len = gdjs.ShowroomCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDSpiderEnemyObjects2[i].setAnimationName("Hurt");
}
for(var i = 0, len = gdjs.ShowroomCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDImpEnemyObjects2[i].setAnimationName("Hurt");
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGhostEnemyObjects2[i].setAnimationFrame(0);
}
for(var i = 0, len = gdjs.ShowroomCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDSpiderEnemyObjects2[i].setAnimationFrame(0);
}
for(var i = 0, len = gdjs.ShowroomCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDImpEnemyObjects2[i].setAnimationFrame(0);
}
}
{ //Subevents
gdjs.ShowroomCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ShowroomCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.ShowroomCode.GDGhostEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.ShowroomCode.GDImpEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.ShowroomCode.GDSpiderEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDBulletObjects2Objects, gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDGhostEnemyObjects2ObjectsGDgdjs_9546ShowroomCode_9546GDSpiderEnemyObjects2ObjectsGDgdjs_9546ShowroomCode_9546GDImpEnemyObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 2;
}
if (isConditionTrue_0) {
/* Reuse gdjs.ShowroomCode.GDBulletObjects2 */
/* Reuse gdjs.ShowroomCode.GDGhostEnemyObjects2 */
/* Reuse gdjs.ShowroomCode.GDImpEnemyObjects2 */
/* Reuse gdjs.ShowroomCode.GDSpiderEnemyObjects2 */
{for(var i = 0, len = gdjs.ShowroomCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGhostEnemyObjects2[i].getBehavior("Health").Hit(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power")) * 0.5, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.ShowroomCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDSpiderEnemyObjects2[i].getBehavior("Health").Hit(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power")) * 0.5, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.ShowroomCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDImpEnemyObjects2[i].getBehavior("Health").Hit(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power")) * 0.5, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGhostEnemyObjects2[i].setAnimationName("Hurt");
}
for(var i = 0, len = gdjs.ShowroomCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDSpiderEnemyObjects2[i].setAnimationName("Hurt");
}
for(var i = 0, len = gdjs.ShowroomCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDImpEnemyObjects2[i].setAnimationName("Hurt");
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGhostEnemyObjects2[i].setAnimationFrame(0);
}
for(var i = 0, len = gdjs.ShowroomCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDSpiderEnemyObjects2[i].setAnimationFrame(0);
}
for(var i = 0, len = gdjs.ShowroomCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDImpEnemyObjects2[i].setAnimationFrame(0);
}
}
{ //Subevents
gdjs.ShowroomCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.ShowroomCode.GDGhostEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.ShowroomCode.GDImpEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.ShowroomCode.GDSpiderEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDGhostEnemyObjects2.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDGhostEnemyObjects2[i].isCurrentAnimationName("Hurt") ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDGhostEnemyObjects2[k] = gdjs.ShowroomCode.GDGhostEnemyObjects2[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDGhostEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDSpiderEnemyObjects2.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDSpiderEnemyObjects2[i].isCurrentAnimationName("Hurt") ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDSpiderEnemyObjects2[k] = gdjs.ShowroomCode.GDSpiderEnemyObjects2[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDSpiderEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDImpEnemyObjects2.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDImpEnemyObjects2[i].isCurrentAnimationName("Hurt") ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDImpEnemyObjects2[k] = gdjs.ShowroomCode.GDImpEnemyObjects2[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDImpEnemyObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDGhostEnemyObjects2.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDGhostEnemyObjects2[i].hasAnimationEnded2() ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDGhostEnemyObjects2[k] = gdjs.ShowroomCode.GDGhostEnemyObjects2[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDGhostEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDSpiderEnemyObjects2.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDSpiderEnemyObjects2[i].hasAnimationEnded2() ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDSpiderEnemyObjects2[k] = gdjs.ShowroomCode.GDSpiderEnemyObjects2[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDSpiderEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDImpEnemyObjects2.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDImpEnemyObjects2[i].hasAnimationEnded2() ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDImpEnemyObjects2[k] = gdjs.ShowroomCode.GDImpEnemyObjects2[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDImpEnemyObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.ShowroomCode.GDGhostEnemyObjects2 */
/* Reuse gdjs.ShowroomCode.GDImpEnemyObjects2 */
/* Reuse gdjs.ShowroomCode.GDSpiderEnemyObjects2 */
{for(var i = 0, len = gdjs.ShowroomCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGhostEnemyObjects2[i].setAnimationName("Walking");
}
for(var i = 0, len = gdjs.ShowroomCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDSpiderEnemyObjects2[i].setAnimationName("Walking");
}
for(var i = 0, len = gdjs.ShowroomCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDImpEnemyObjects2[i].setAnimationName("Walking");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.ShowroomCode.GDGhostEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.ShowroomCode.GDImpEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.ShowroomCode.GDSpiderEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDGhostEnemyObjects1.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDGhostEnemyObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDGhostEnemyObjects1[k] = gdjs.ShowroomCode.GDGhostEnemyObjects1[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDGhostEnemyObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDSpiderEnemyObjects1.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDSpiderEnemyObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDSpiderEnemyObjects1[k] = gdjs.ShowroomCode.GDSpiderEnemyObjects1[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDSpiderEnemyObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDImpEnemyObjects1.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDImpEnemyObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDImpEnemyObjects1[k] = gdjs.ShowroomCode.GDImpEnemyObjects1[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDImpEnemyObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.ShowroomCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.ShowroomCode.GDEnemyBulletObjects2});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ShowroomCode.GDPlayerObjects2});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.ShowroomCode.GDEnemyBulletObjects2});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.ShowroomCode.GDBulletObjects2});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ShowroomCode.GDPlayerObjects2});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDHeartObjects2Objects = Hashtable.newFrom({"Heart": gdjs.ShowroomCode.GDHeartObjects2});
gdjs.ShowroomCode.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__SpriteMultitouchJoystick__IsDirectionPushed4Way.func(runtimeScene, 2, "Secondary", "Left", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.ShowroomCode.GDGunObjects4);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects4);
{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects4[i].flipX(true);
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDGunObjects4.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGunObjects4[i].flipY(true);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__SpriteMultitouchJoystick__IsDirectionPushed4Way.func(runtimeScene, 2, "Secondary", "Right", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.ShowroomCode.GDGunObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects3);
{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects3[i].flipX(false);
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGunObjects3[i].flipY(false);
}
}}

}


};gdjs.ShowroomCode.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDPlayerObjects4[i].getX() < gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDPlayerObjects4[k] = gdjs.ShowroomCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDPlayerObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.ShowroomCode.GDGunObjects4);
/* Reuse gdjs.ShowroomCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects4[i].flipX(false);
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDGunObjects4.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGunObjects4[i].flipY(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDPlayerObjects3[i].getX() > gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDPlayerObjects3[k] = gdjs.ShowroomCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.ShowroomCode.GDGunObjects3);
/* Reuse gdjs.ShowroomCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects3[i].flipX(true);
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGunObjects3[i].flipY(true);
}
}}

}


};gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.ShowroomCode.GDBulletObjects3});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.ShowroomCode.GDBulletObjects2});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.ShowroomCode.GDPlayerObjects2});
gdjs.ShowroomCode.eventsList14 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.ShowroomCode.GDGunObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects3);
{for(var i = 0, len = gdjs.ShowroomCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGunObjects3[i].setPosition((( gdjs.ShowroomCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.ShowroomCode.GDPlayerObjects3[0].getPointX("Gun")),(( gdjs.ShowroomCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.ShowroomCode.GDPlayerObjects3[0].getPointY("Gun")));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isMobile());
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.ShowroomCode.GDGunObjects3);
{for(var i = 0, len = gdjs.ShowroomCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGunObjects3[i].rotateTowardPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 0, runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isMobile();
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.ShowroomCode.GDGunObjects3);
{for(var i = 0, len = gdjs.ShowroomCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGunObjects3[i].rotateTowardAngle(gdjs.evtsExt__SpriteMultitouchJoystick__StickAngle.func(runtimeScene, 2, "Secondary", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), 0, runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isMobile();
if (isConditionTrue_0) {

{ //Subevents
gdjs.ShowroomCode.eventsList12(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isMobile());
if (isConditionTrue_0) {

{ //Subevents
gdjs.ShowroomCode.eventsList13(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = !(gdjs.evtTools.systemInfo.isMobile());
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtsExt__SpriteMultitouchJoystick__StickForce.func(runtimeScene, 2, "Secondary", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) > 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ShowroomCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.ShowroomCode.GDGunObjects3);
{for(var i = 0, len = gdjs.ShowroomCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGunObjects3[i].getBehavior("FireBullet").Fire((gdjs.ShowroomCode.GDGunObjects3[i].getPointX("BulletPoint")), (gdjs.ShowroomCode.GDGunObjects3[i].getPointY("BulletPoint")), gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDBulletObjects3Objects, (gdjs.ShowroomCode.GDGunObjects3[i].getAngle()), 200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.ShowroomCode.GDGunObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDGunObjects3.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDGunObjects3[i].getBehavior("FireBullet").HasJustFired((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.ShowroomCode.GDGunObjects3[k] = gdjs.ShowroomCode.GDGunObjects3[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDGunObjects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 1;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ShowroomCode.GDBulletObjects3);
{for(var i = 0, len = gdjs.ShowroomCode.GDBulletObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDBulletObjects3[i].setAnimationName("lasergun");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Gun", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Sound")), gdjs.randomFloatInRange(0.8, 1));
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.1, 0, 0.05, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.ShowroomCode.GDGunObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDGunObjects3.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDGunObjects3[i].getBehavior("FireBullet").HasJustFired((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.ShowroomCode.GDGunObjects3[k] = gdjs.ShowroomCode.GDGunObjects3[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDGunObjects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) == 2;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ShowroomCode.GDBulletObjects3);
{for(var i = 0, len = gdjs.ShowroomCode.GDBulletObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDBulletObjects3[i].setAnimationName("minigun");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Gun", false, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Sound")), gdjs.randomFloatInRange(0.8, 1));
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.1, 0, 0.05, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
{
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ShowroomCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDBulletObjects2Objects, gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDPlayerObjects2Objects, 400, true);
if (isConditionTrue_0) {
/* Reuse gdjs.ShowroomCode.GDBulletObjects2 */
{for(var i = 0, len = gdjs.ShowroomCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDWallCollisionObjects2Objects = Hashtable.newFrom({"WallCollision": gdjs.ShowroomCode.GDWallCollisionObjects2});
gdjs.ShowroomCode.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("WallCollision"), gdjs.ShowroomCode.GDWallCollisionObjects2);
{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects2[i].separateFromObjectsList(gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDWallCollisionObjects2Objects, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDPlayerObjects2[k] = gdjs.ShowroomCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.ShowroomCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects2[i].setAnimationName("Run");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.ShowroomCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDPlayerObjects1[k] = gdjs.ShowroomCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.ShowroomCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects1[i].setAnimationName("Idle");
}
}}

}


};gdjs.ShowroomCode.eventsList16 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.ShowroomCode.GDEnemyBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDEnemyBulletObjects2Objects, gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.ShowroomCode.GDEnemyBulletObjects2 */
/* Reuse gdjs.ShowroomCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.ShowroomCode.GDEnemyBulletObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDEnemyBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects2[i].getBehavior("Health").Hit(2, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.ShowroomCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.ShowroomCode.GDEnemyBulletObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDEnemyBulletObjects2Objects, gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDBulletObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.ShowroomCode.GDBulletObjects2 */
/* Reuse gdjs.ShowroomCode.GDEnemyBulletObjects2 */
{for(var i = 0, len = gdjs.ShowroomCode.GDEnemyBulletObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDEnemyBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Heart"), gdjs.ShowroomCode.GDHeartObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDPlayerObjects2Objects, gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDHeartObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.ShowroomCode.GDHeartObjects2 */
/* Reuse gdjs.ShowroomCode.GDPlayerObjects2 */
gdjs.copyArray(runtimeScene.getObjects("PlayerHealthBar"), gdjs.ShowroomCode.GDPlayerHealthBarObjects2);
{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects2[i].getBehavior("Health").Heal(2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerHealthBarObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerHealthBarObjects2[i].SetValue(gdjs.ShowroomCode.GDPlayerHealthBarObjects2[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) + (2), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDHeartObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDHeartObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(2).sub(1);
}}

}


{


gdjs.ShowroomCode.eventsList14(runtimeScene);
}


{


gdjs.ShowroomCode.eventsList15(runtimeScene);
}


};gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDGhostEnemyObjects2ObjectsGDgdjs_9546ShowroomCode_9546GDSpiderEnemyObjects2ObjectsGDgdjs_9546ShowroomCode_9546GDImpEnemyObjects2Objects = Hashtable.newFrom({"GhostEnemy": gdjs.ShowroomCode.GDGhostEnemyObjects2, "SpiderEnemy": gdjs.ShowroomCode.GDSpiderEnemyObjects2, "ImpEnemy": gdjs.ShowroomCode.GDImpEnemyObjects2});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDCenterObjects2Objects = Hashtable.newFrom({"Center": gdjs.ShowroomCode.GDCenterObjects2});
gdjs.ShowroomCode.asyncCallback16138708 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects3);

{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects3[i].getBehavior("Effect").enableEffect("Damaged", false);
}
}}
gdjs.ShowroomCode.eventsList17 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.ShowroomCode.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.ShowroomCode.asyncCallback16138708(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.ShowroomCode.GDEnemyBulletObjects2});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDCenterObjects2Objects = Hashtable.newFrom({"Center": gdjs.ShowroomCode.GDCenterObjects2});
gdjs.ShowroomCode.asyncCallback16142068 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects3);

{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects3[i].getBehavior("Effect").enableEffect("Damaged", false);
}
}}
gdjs.ShowroomCode.eventsList18 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.ShowroomCode.GDPlayerObjects2) asyncObjectsList.addObject("Player", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.ShowroomCode.asyncCallback16142068(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.ShowroomCode.eventsList19 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.ShowroomCode.GDCenterObjects2);
gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.ShowroomCode.GDGhostEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.ShowroomCode.GDImpEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.ShowroomCode.GDSpiderEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDGhostEnemyObjects2ObjectsGDgdjs_9546ShowroomCode_9546GDSpiderEnemyObjects2ObjectsGDgdjs_9546ShowroomCode_9546GDImpEnemyObjects2Objects, gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDCenterObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16137724);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerHealthBar"), gdjs.ShowroomCode.GDPlayerHealthBarObjects2);
{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects2[i].getBehavior("Health").Hit(1, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerHealthBarObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerHealthBarObjects2[i].SetValue(gdjs.ShowroomCode.GDPlayerHealthBarObjects2[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (1), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.1, 0, 0.05, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects2[i].getBehavior("Effect").enableEffect("Damaged", true);
}
}
{ //Subevents
gdjs.ShowroomCode.eventsList17(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.ShowroomCode.GDCenterObjects2);
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.ShowroomCode.GDEnemyBulletObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDEnemyBulletObjects2Objects, gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDCenterObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16140476);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("PlayerHealthBar"), gdjs.ShowroomCode.GDPlayerHealthBarObjects2);
{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects2[i].getBehavior("Health").Hit(1, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerHealthBarObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerHealthBarObjects2[i].SetValue(gdjs.ShowroomCode.GDPlayerHealthBarObjects2[i].Value((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) - (1), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.1, 0, 0.05, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects2[i].getBehavior("Effect").enableEffect("Damaged", true);
}
}
{ //Subevents
gdjs.ShowroomCode.eventsList18(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDPlayerObjects1[i].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDPlayerObjects1[k] = gdjs.ShowroomCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}}

}


};gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDEXP_95959595PointObjects3Objects = Hashtable.newFrom({"EXP_Point": gdjs.ShowroomCode.GDEXP_9595PointObjects3});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.ShowroomCode.GDPlayerObjects3});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDEXP_95959595PointObjects3Objects = Hashtable.newFrom({"EXP_Point": gdjs.ShowroomCode.GDEXP_9595PointObjects3});
gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.ShowroomCode.GDPlayerObjects3});
gdjs.ShowroomCode.eventsList20 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Darken"), gdjs.ShowroomCode.GDDarkenObjects3);
{for(var i = 0, len = gdjs.ShowroomCode.GDDarkenObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDDarkenObjects3[i].drawRectangle(0, gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "LevelUp", 0), gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "LevelUp", 0), gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "LevelUp", 0));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("EXP_Point"), gdjs.ShowroomCode.GDEXP_9595PointObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDEXP_95959595PointObjects3Objects, gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDPlayerObjects3Objects, 50, false);
if (isConditionTrue_0) {
/* Reuse gdjs.ShowroomCode.GDEXP_9595PointObjects3 */
/* Reuse gdjs.ShowroomCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.ShowroomCode.GDEXP_9595PointObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDEXP_9595PointObjects3[i].addForceTowardObject((gdjs.ShowroomCode.GDPlayerObjects3.length !== 0 ? gdjs.ShowroomCode.GDPlayerObjects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("EXP_Point"), gdjs.ShowroomCode.GDEXP_9595PointObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDEXP_95959595PointObjects3Objects, gdjs.ShowroomCode.mapOfGDgdjs_9546ShowroomCode_9546GDPlayerObjects3Objects, 3, false);
if (isConditionTrue_0) {
/* Reuse gdjs.ShowroomCode.GDEXP_9595PointObjects3 */
gdjs.copyArray(runtimeScene.getObjects("RedFlatBar"), gdjs.ShowroomCode.GDRedFlatBarObjects3);
{for(var i = 0, len = gdjs.ShowroomCode.GDEXP_9595PointObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDEXP_9595PointObjects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("CurrentEXP").add(1);
}{for(var i = 0, len = gdjs.ShowroomCode.GDRedFlatBarObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDRedFlatBarObjects3[i].SetMaxValue(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("MaxEXP")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDRedFlatBarObjects3.length ;i < len;++i) {
    gdjs.ShowroomCode.GDRedFlatBarObjects3[i].SetValue(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("CurrentEXP")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("CurrentEXP")) >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("MaxEXP"));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("RedFlatBar"), gdjs.ShowroomCode.GDRedFlatBarObjects2);
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}{gdjs.evtTools.camera.showLayer(runtimeScene, "LevelUp");
}{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("CurrentEXP").setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("MaxEXP").setNumber(Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("MaxEXP")) * 1.5));
}{for(var i = 0, len = gdjs.ShowroomCode.GDRedFlatBarObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDRedFlatBarObjects2[i].SetValue(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("CurrentEXP")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.ShowroomCode.GDRedFlatBarObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDRedFlatBarObjects2[i].SetMaxValue(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("MaxEXP")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.ShowroomCode.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.ShowroomCode.GDPowerButtonObjects1, gdjs.ShowroomCode.GDPowerButtonObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDPowerButtonObjects2.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDPowerButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDPowerButtonObjects2[k] = gdjs.ShowroomCode.GDPowerButtonObjects2[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDPowerButtonObjects2.length = k;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power").add(1);
}}

}


{

gdjs.copyArray(gdjs.ShowroomCode.GDFireRateButtonObjects1, gdjs.ShowroomCode.GDFireRateButtonObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDFireRateButtonObjects2.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDFireRateButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDFireRateButtonObjects2[k] = gdjs.ShowroomCode.GDFireRateButtonObjects2[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDFireRateButtonObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.ShowroomCode.GDGunObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("FireRate").add(1);
}{for(var i = 0, len = gdjs.ShowroomCode.GDGunObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGunObjects2[i].getBehavior("FireBullet").SetCooldownOp((gdjs.ShowroomCode.GDGunObjects2[i].getBehavior("FireBullet").Cooldown((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) * 0.9, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(gdjs.ShowroomCode.GDAccuracyButtonObjects1, gdjs.ShowroomCode.GDAccuracyButtonObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDAccuracyButtonObjects2.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDAccuracyButtonObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDAccuracyButtonObjects2[k] = gdjs.ShowroomCode.GDAccuracyButtonObjects2[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDAccuracyButtonObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.ShowroomCode.GDGunObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Accuracy").add(1);
}{for(var i = 0, len = gdjs.ShowroomCode.GDGunObjects2.length ;i < len;++i) {
    gdjs.ShowroomCode.GDGunObjects2[i].getBehavior("FireBullet").SetAngleVarianceOp((gdjs.ShowroomCode.GDGunObjects2[i].getBehavior("FireBullet").AngleVariance((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) * 0.9, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Stats"), gdjs.ShowroomCode.GDStatsObjects1);
{for(var i = 0, len = gdjs.ShowroomCode.GDStatsObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDStatsObjects1[i].setText("Power: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power"))) + "\nFire Rate: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("FireRate"))) + "\nAccuracy: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Accuracy"))));
}
}}

}


};gdjs.ShowroomCode.eventsList22 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("AccuracyButton"), gdjs.ShowroomCode.GDAccuracyButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("FireRateButton"), gdjs.ShowroomCode.GDFireRateButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("PowerButton"), gdjs.ShowroomCode.GDPowerButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDPowerButtonObjects1.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDPowerButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDPowerButtonObjects1[k] = gdjs.ShowroomCode.GDPowerButtonObjects1[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDPowerButtonObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDFireRateButtonObjects1.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDFireRateButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDFireRateButtonObjects1[k] = gdjs.ShowroomCode.GDFireRateButtonObjects1[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDFireRateButtonObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.ShowroomCode.GDAccuracyButtonObjects1.length;i<l;++i) {
    if ( gdjs.ShowroomCode.GDAccuracyButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.ShowroomCode.GDAccuracyButtonObjects1[k] = gdjs.ShowroomCode.GDAccuracyButtonObjects1[i];
        ++k;
    }
}
gdjs.ShowroomCode.GDAccuracyButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "LevelUp");
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "LevelUp");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}
{ //Subevents
gdjs.ShowroomCode.eventsList21(runtimeScene);} //End of subevents
}

}


};gdjs.ShowroomCode.eventsList23 = function(runtimeScene) {

{


gdjs.ShowroomCode.eventsList20(runtimeScene);
}


{


gdjs.ShowroomCode.eventsList22(runtimeScene);
}


};gdjs.ShowroomCode.eventsList24 = function(runtimeScene) {

{


gdjs.ShowroomCode.eventsList1(runtimeScene);
}


{


gdjs.ShowroomCode.eventsList2(runtimeScene);
}


{


gdjs.ShowroomCode.eventsList11(runtimeScene);
}


{


gdjs.ShowroomCode.eventsList16(runtimeScene);
}


{


gdjs.ShowroomCode.eventsList19(runtimeScene);
}


{


gdjs.ShowroomCode.eventsList23(runtimeScene);
}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").simulateUpKey();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.ShowroomCode.GDPlayerObjects1);
{for(var i = 0, len = gdjs.ShowroomCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.ShowroomCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


};

gdjs.ShowroomCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ShowroomCode.GDFloorObjects1.length = 0;
gdjs.ShowroomCode.GDFloorObjects2.length = 0;
gdjs.ShowroomCode.GDFloorObjects3.length = 0;
gdjs.ShowroomCode.GDFloorObjects4.length = 0;
gdjs.ShowroomCode.GDFloorObjects5.length = 0;
gdjs.ShowroomCode.GDPlayerObjects1.length = 0;
gdjs.ShowroomCode.GDPlayerObjects2.length = 0;
gdjs.ShowroomCode.GDPlayerObjects3.length = 0;
gdjs.ShowroomCode.GDPlayerObjects4.length = 0;
gdjs.ShowroomCode.GDPlayerObjects5.length = 0;
gdjs.ShowroomCode.GDGunObjects1.length = 0;
gdjs.ShowroomCode.GDGunObjects2.length = 0;
gdjs.ShowroomCode.GDGunObjects3.length = 0;
gdjs.ShowroomCode.GDGunObjects4.length = 0;
gdjs.ShowroomCode.GDGunObjects5.length = 0;
gdjs.ShowroomCode.GDBulletObjects1.length = 0;
gdjs.ShowroomCode.GDBulletObjects2.length = 0;
gdjs.ShowroomCode.GDBulletObjects3.length = 0;
gdjs.ShowroomCode.GDBulletObjects4.length = 0;
gdjs.ShowroomCode.GDBulletObjects5.length = 0;
gdjs.ShowroomCode.GDGhostEnemyObjects1.length = 0;
gdjs.ShowroomCode.GDGhostEnemyObjects2.length = 0;
gdjs.ShowroomCode.GDGhostEnemyObjects3.length = 0;
gdjs.ShowroomCode.GDGhostEnemyObjects4.length = 0;
gdjs.ShowroomCode.GDGhostEnemyObjects5.length = 0;
gdjs.ShowroomCode.GDSpiderEnemyObjects1.length = 0;
gdjs.ShowroomCode.GDSpiderEnemyObjects2.length = 0;
gdjs.ShowroomCode.GDSpiderEnemyObjects3.length = 0;
gdjs.ShowroomCode.GDSpiderEnemyObjects4.length = 0;
gdjs.ShowroomCode.GDSpiderEnemyObjects5.length = 0;
gdjs.ShowroomCode.GDImpEnemyObjects1.length = 0;
gdjs.ShowroomCode.GDImpEnemyObjects2.length = 0;
gdjs.ShowroomCode.GDImpEnemyObjects3.length = 0;
gdjs.ShowroomCode.GDImpEnemyObjects4.length = 0;
gdjs.ShowroomCode.GDImpEnemyObjects5.length = 0;
gdjs.ShowroomCode.GDCenterObjects1.length = 0;
gdjs.ShowroomCode.GDCenterObjects2.length = 0;
gdjs.ShowroomCode.GDCenterObjects3.length = 0;
gdjs.ShowroomCode.GDCenterObjects4.length = 0;
gdjs.ShowroomCode.GDCenterObjects5.length = 0;
gdjs.ShowroomCode.GDSpawnPointsObjects1.length = 0;
gdjs.ShowroomCode.GDSpawnPointsObjects2.length = 0;
gdjs.ShowroomCode.GDSpawnPointsObjects3.length = 0;
gdjs.ShowroomCode.GDSpawnPointsObjects4.length = 0;
gdjs.ShowroomCode.GDSpawnPointsObjects5.length = 0;
gdjs.ShowroomCode.GDSpiderSpawnPointsObjects1.length = 0;
gdjs.ShowroomCode.GDSpiderSpawnPointsObjects2.length = 0;
gdjs.ShowroomCode.GDSpiderSpawnPointsObjects3.length = 0;
gdjs.ShowroomCode.GDSpiderSpawnPointsObjects4.length = 0;
gdjs.ShowroomCode.GDSpiderSpawnPointsObjects5.length = 0;
gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects1.length = 0;
gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects2.length = 0;
gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects3.length = 0;
gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects4.length = 0;
gdjs.ShowroomCode.GDHealthBar_9595EnemyObjects5.length = 0;
gdjs.ShowroomCode.GDWallCollisionObjects1.length = 0;
gdjs.ShowroomCode.GDWallCollisionObjects2.length = 0;
gdjs.ShowroomCode.GDWallCollisionObjects3.length = 0;
gdjs.ShowroomCode.GDWallCollisionObjects4.length = 0;
gdjs.ShowroomCode.GDWallCollisionObjects5.length = 0;
gdjs.ShowroomCode.GDvignetteObjects1.length = 0;
gdjs.ShowroomCode.GDvignetteObjects2.length = 0;
gdjs.ShowroomCode.GDvignetteObjects3.length = 0;
gdjs.ShowroomCode.GDvignetteObjects4.length = 0;
gdjs.ShowroomCode.GDvignetteObjects5.length = 0;
gdjs.ShowroomCode.GDRedFlatBarObjects1.length = 0;
gdjs.ShowroomCode.GDRedFlatBarObjects2.length = 0;
gdjs.ShowroomCode.GDRedFlatBarObjects3.length = 0;
gdjs.ShowroomCode.GDRedFlatBarObjects4.length = 0;
gdjs.ShowroomCode.GDRedFlatBarObjects5.length = 0;
gdjs.ShowroomCode.GDEXP_9595PointObjects1.length = 0;
gdjs.ShowroomCode.GDEXP_9595PointObjects2.length = 0;
gdjs.ShowroomCode.GDEXP_9595PointObjects3.length = 0;
gdjs.ShowroomCode.GDEXP_9595PointObjects4.length = 0;
gdjs.ShowroomCode.GDEXP_9595PointObjects5.length = 0;
gdjs.ShowroomCode.GDStatsObjects1.length = 0;
gdjs.ShowroomCode.GDStatsObjects2.length = 0;
gdjs.ShowroomCode.GDStatsObjects3.length = 0;
gdjs.ShowroomCode.GDStatsObjects4.length = 0;
gdjs.ShowroomCode.GDStatsObjects5.length = 0;
gdjs.ShowroomCode.GDPowerButtonObjects1.length = 0;
gdjs.ShowroomCode.GDPowerButtonObjects2.length = 0;
gdjs.ShowroomCode.GDPowerButtonObjects3.length = 0;
gdjs.ShowroomCode.GDPowerButtonObjects4.length = 0;
gdjs.ShowroomCode.GDPowerButtonObjects5.length = 0;
gdjs.ShowroomCode.GDFireRateButtonObjects1.length = 0;
gdjs.ShowroomCode.GDFireRateButtonObjects2.length = 0;
gdjs.ShowroomCode.GDFireRateButtonObjects3.length = 0;
gdjs.ShowroomCode.GDFireRateButtonObjects4.length = 0;
gdjs.ShowroomCode.GDFireRateButtonObjects5.length = 0;
gdjs.ShowroomCode.GDAccuracyButtonObjects1.length = 0;
gdjs.ShowroomCode.GDAccuracyButtonObjects2.length = 0;
gdjs.ShowroomCode.GDAccuracyButtonObjects3.length = 0;
gdjs.ShowroomCode.GDAccuracyButtonObjects4.length = 0;
gdjs.ShowroomCode.GDAccuracyButtonObjects5.length = 0;
gdjs.ShowroomCode.GDWaveNumberObjects1.length = 0;
gdjs.ShowroomCode.GDWaveNumberObjects2.length = 0;
gdjs.ShowroomCode.GDWaveNumberObjects3.length = 0;
gdjs.ShowroomCode.GDWaveNumberObjects4.length = 0;
gdjs.ShowroomCode.GDWaveNumberObjects5.length = 0;
gdjs.ShowroomCode.GDEnemyBulletObjects1.length = 0;
gdjs.ShowroomCode.GDEnemyBulletObjects2.length = 0;
gdjs.ShowroomCode.GDEnemyBulletObjects3.length = 0;
gdjs.ShowroomCode.GDEnemyBulletObjects4.length = 0;
gdjs.ShowroomCode.GDEnemyBulletObjects5.length = 0;
gdjs.ShowroomCode.GDShadowObjects1.length = 0;
gdjs.ShowroomCode.GDShadowObjects2.length = 0;
gdjs.ShowroomCode.GDShadowObjects3.length = 0;
gdjs.ShowroomCode.GDShadowObjects4.length = 0;
gdjs.ShowroomCode.GDShadowObjects5.length = 0;
gdjs.ShowroomCode.GDDropObjects1.length = 0;
gdjs.ShowroomCode.GDDropObjects2.length = 0;
gdjs.ShowroomCode.GDDropObjects3.length = 0;
gdjs.ShowroomCode.GDDropObjects4.length = 0;
gdjs.ShowroomCode.GDDropObjects5.length = 0;
gdjs.ShowroomCode.GDMovementObjects1.length = 0;
gdjs.ShowroomCode.GDMovementObjects2.length = 0;
gdjs.ShowroomCode.GDMovementObjects3.length = 0;
gdjs.ShowroomCode.GDMovementObjects4.length = 0;
gdjs.ShowroomCode.GDMovementObjects5.length = 0;
gdjs.ShowroomCode.GDAimingObjects1.length = 0;
gdjs.ShowroomCode.GDAimingObjects2.length = 0;
gdjs.ShowroomCode.GDAimingObjects3.length = 0;
gdjs.ShowroomCode.GDAimingObjects4.length = 0;
gdjs.ShowroomCode.GDAimingObjects5.length = 0;
gdjs.ShowroomCode.GDPlayerHealthBarObjects1.length = 0;
gdjs.ShowroomCode.GDPlayerHealthBarObjects2.length = 0;
gdjs.ShowroomCode.GDPlayerHealthBarObjects3.length = 0;
gdjs.ShowroomCode.GDPlayerHealthBarObjects4.length = 0;
gdjs.ShowroomCode.GDPlayerHealthBarObjects5.length = 0;
gdjs.ShowroomCode.GDHeartObjects1.length = 0;
gdjs.ShowroomCode.GDHeartObjects2.length = 0;
gdjs.ShowroomCode.GDHeartObjects3.length = 0;
gdjs.ShowroomCode.GDHeartObjects4.length = 0;
gdjs.ShowroomCode.GDHeartObjects5.length = 0;
gdjs.ShowroomCode.GDHeart2Objects1.length = 0;
gdjs.ShowroomCode.GDHeart2Objects2.length = 0;
gdjs.ShowroomCode.GDHeart2Objects3.length = 0;
gdjs.ShowroomCode.GDHeart2Objects4.length = 0;
gdjs.ShowroomCode.GDHeart2Objects5.length = 0;
gdjs.ShowroomCode.GDTransitionObjects1.length = 0;
gdjs.ShowroomCode.GDTransitionObjects2.length = 0;
gdjs.ShowroomCode.GDTransitionObjects3.length = 0;
gdjs.ShowroomCode.GDTransitionObjects4.length = 0;
gdjs.ShowroomCode.GDTransitionObjects5.length = 0;
gdjs.ShowroomCode.GDDarkenObjects1.length = 0;
gdjs.ShowroomCode.GDDarkenObjects2.length = 0;
gdjs.ShowroomCode.GDDarkenObjects3.length = 0;
gdjs.ShowroomCode.GDDarkenObjects4.length = 0;
gdjs.ShowroomCode.GDDarkenObjects5.length = 0;

gdjs.ShowroomCode.eventsList24(runtimeScene);

return;

}

gdjs['ShowroomCode'] = gdjs.ShowroomCode;
